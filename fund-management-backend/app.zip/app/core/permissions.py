# Permission helpers placeholder
