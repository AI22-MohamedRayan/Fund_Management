# Validation helpers placeholder
